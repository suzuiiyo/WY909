﻿#include "storeiedinfo.h"

storeIedinfo::storeIedinfo(QStringList &iedList, QStringList &fileList)
{
    
    
}
