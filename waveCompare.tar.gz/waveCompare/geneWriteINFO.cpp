#include "geneWriteINFO.h"

geneWriteINFO::geneWriteINFO()
{

}
