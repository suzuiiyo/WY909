#ifndef GENEXMLRESULT_H
#define GENEXMLRESULT_H


class geneWriteINFO
{
public:
    geneWriteINFO();
};

#endif // GENEXMLRESULT_H
