#include "writeswitchdao.h"

writeSwitchdao::writeSwitchdao()
{

}
